document.querySelectorAll(".thumbnail").forEach((img) => {
  img.addEventListener("click", function () {
    document.getElementById("fullsize-img").src = this.src;
  });
});
