// Решение методом цикла

const elementsAll = document.querySelectorAll(".img-cat");

for (var i = 0; i < elementsAll.length; i++) {
  (function (index) {
    const imgEl = elementsAll[index];

    imgEl.addEventListener("click", function () {
      const imgUrl = imgEl.getAttribute("src");
      const container = document.getElementById("container");
      container.innerHTML = "";

      const fullImg = document.createElement("img");
      fullImg.setAttribute("src", imgUrl);
      fullImg.setAttribute("width", "600");
      fullImg.setAttribute("alt", "Полноразмерное изображение");

      container.appendChild(fullImg);

      console.log(`Миниатюра №${index + 1}, URL: ${imgUrl}`);
    });
  })(i);
}
