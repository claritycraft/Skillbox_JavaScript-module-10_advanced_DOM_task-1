// 1. Создаем переменную
const thumbnails = document.querySelectorAll(".img-cat");

// 2. Перебираем каждую миниатюру
thumbnails.forEach((imgEl, index) => {
  // 3. Навешиваем обработчик клика
  imgEl.addEventListener("click", () => {
    // 4. Получаем URL изображения
    const imgUrl = imgEl.getAttribute("src");

    // 5. Находим контейнер и очищаем его
    const container = document.getElementById("container");
    container.innerHTML = "";

    // 6. Создаём новое изображение
    const fullImg = document.createElement("img");
    fullImg.setAttribute("src", imgUrl);
    fullImg.setAttribute("width", "600");
    fullImg.setAttribute("alt", "Полноразмерное изображение");

    // 7. Добавляем изображение в контейнер
    container.appendChild(fullImg);

    // 8. Выводим в консоль
    // console.log(`Миниатюра №${index + 1}, URL: ${imgUrl}`);
  });
});

// *Пояснения
// Вот как forEach работает внутри (то есть этот метод базируется на цикле):
// for (let i = 0; i < array.length; i++) {
//      const element = array[i];
//      const index = i;
//      callback(element, index, array);
// }
